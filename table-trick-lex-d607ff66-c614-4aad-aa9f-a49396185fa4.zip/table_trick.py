import json
import os
import logging
import boto3
import requests
import random


######## Convert SSML to Card text ############
from html.parser import HTMLParser
from six import PY2
try:
    from HTMLParser import HTMLParser
except ImportError:
    from html.parser import HTMLParser


class SSMLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.full_str_list = []
        if not PY2:
            self.strict = False
            self.convert_charrefs = True

    def handle_data(self, d):
        self.full_str_list.append(d)

    def get_data(self):
        return ''.join(self.full_str_list)


def convert_html_to_text(html_data):
    # convert ssml speech to text, by removing html tags
    s = SSMLStripper()
    s.feed(html_data)
    return s.get_data()

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
max_question = 5

def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message, response_card):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ElicitSlot',
            'intentName': intent_name,
            'slots': slots,
            'slotToElicit': slot_to_elicit,
            'message': message,
            'responseCard': response_card
        }
    }


def confirm_intent(session_attributes, intent_name, slots, message, response_card):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ConfirmIntent',
            'intentName': intent_name,
            'slots': slots,
            'message': message,
            'responseCard': response_card
        }
    }


def close(session_attributes, fulfillment_state, message):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message
        }
    }

    return response


def delegate(session_attributes, slots):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Delegate',
            'slots': slots
        }
    }


def build_response_card(title, subtitle, options):
    """
    Build a responseCard with a title, subtitle, and an optional set of options which should be displayed as buttons.
    """
    buttons = None
    if options is not None:
        buttons = []
        for i in range(min(5, len(options))):
            buttons.append(options[i])

    return {
        'contentType': 'application/vnd.amazonaws.card.generic',
        'version': 1,
        'genericAttachments': [{
            'title': title,
            'subTitle': subtitle,
            'buttons': buttons
        }]
    }


def parse_int(n):
    try:
        return int(n)
    except ValueError:
        return float('nan')


def try_ex(func):
    """
    Call passed in function in try block. If KeyError is encountered return None.
    This function is intended to be used to safely access dictionary.

    Note that this function would have negative impact on performance.
    """
    try:
        return func()
    except KeyError:
        return None


def get_random_int(minimum, maximum):
    """
    Returns a random integer between min (included) and max (excluded)
    """
    min_int = math.ceil(minimum)
    max_int = math.floor(maximum)

    return random.randint(min_int, max_int - 1)


def build_validation_result(is_valid, violated_slot, message_content, session_attributes):
    return {
        'isValid': is_valid,
        'violatedSlot': violated_slot,
        'message': {'contentType': 'PlainText', 'content': message_content},
        'session_attributes': session_attributes
    }


def build_options(slot):
    """
    Build a list of potential options for a given slot, to be used in responseCard generation.
    """
        
    if slot == 'Out_Language':
        out_card = list()
        for ln in lang_codes.keys():
            out_card.append({'text':ln,'value':ln})
        return out_card
    options = []       

    return options

""" --- Functions that control the bot's behavior --- """


def get_numbers(session_attributes):
    matrix = json.loads(session_attributes['matrix'])['data']
    print(matrix)
    index = random.randint(0, len(matrix)-1)
    i = matrix[index][0]
    j = matrix[index][1]
    matrix.pop(index)
    return [i,j,json.dumps({"data":matrix})]


def validate_input(intent_name, session_attributes, answer):
    
    res = get_numbers(session_attributes)
    text_result = ''
    i = res[0]
    j = res[1]
    session_attributes['matrix'] = res[2]
    
    if answer in [None, ''] and int(session_attributes['count']) > 0:
        return  build_validation_result(
                                            False, 'Answer', 'Please repeat the answer', session_attributes
                                        )
        
    
    if int(session_attributes['count']) == 0:
        session_attributes['count'] = int(session_attributes['count']) + 1
        session_attributes['correct_answer'] = i * j
        return  build_validation_result(
                                        False, 'Answer',
                                        "{0}, Question {1}. Please tell value of {2} into {3}?".format('',
                                        session_attributes['count'],
                                        i, j), session_attributes
                                        )
                                        
    elif int(session_attributes['count']) < max_question:
        session_attributes['count'] = int(session_attributes['count']) + 1
        if 'correct_answer' in session_attributes:
            if int(session_attributes['correct_answer']) == int(answer):
                text_result = 'Correct!'
                session_attributes['score'] = int(session_attributes['score']) + 1
            else:
                text_result = 'Wrong!'
            session_attributes['correct_answer'] = i * j
            return  build_validation_result(
                                        False, 'Answer',
                                        "{0}, Question {1}. Please tell value of {2} into {3}?".format(text_result,
                                        session_attributes['count'],
                                        i, j), session_attributes
                                        )
    else:
        if int(session_attributes['correct_answer']) == int(answer):
                session_attributes['score'] = int(session_attributes['score']) + 1
        return  build_validation_result(True, None, None, session_attributes)
    
    
def table_trick(intent_request):
    
    if 'Answer' in intent_request['currentIntent']['slots']:
        answer = intent_request['currentIntent']['slots']['Answer']
    else:
        answer = None
   
    source = intent_request['invocationSource']
    output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    intent_name = intent_request['currentIntent']['name']
    
    if 'matrix' not in output_session_attributes:
        matrix = list()
        for i in range(2,16):
            for x in range(2,11):
                matrix.append([i, x])
        output_session_attributes['matrix'] = json.dumps({"data":matrix})
                
    if 'score' not in output_session_attributes:
        output_session_attributes['score'] = 0
        output_session_attributes['count'] = 0

    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        slots = intent_request['currentIntent']['slots']
        validation_result = validate_input(intent_name, output_session_attributes, answer)
            
        if not validation_result['isValid']:
            #slots[validation_result['violatedSlot']] = None
            return elicit_slot(
                validation_result['session_attributes'],
                intent_request['currentIntent']['name'],
                slots,
                validation_result['violatedSlot'],
                validation_result['message'],
                None
                )
        
        return delegate(validation_result['session_attributes'], slots)
        
    
    output_content = 'You scored {0} out of {1}. Keep it up'.format(output_session_attributes['score'], max_question)
    output_session_attributes = {}
    return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': json.dumps(output_content)
        }
    )
""" --- Intents --- """

def dispatch(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """
    intent_name = intent_request['currentIntent']['name']
        
    if intent_name == 'QuizIntent':
        return table_trick(intent_request)
        
    raise Exception('Intent with name ' + intent_name + ' not supported')


""" --- Main handler --- """

def lambda_handler(event, context):
    """
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    """
    # logger.debug('event.bot.name={}'.format(event['bot']['name']))
    print(event)
    return dispatch(event)