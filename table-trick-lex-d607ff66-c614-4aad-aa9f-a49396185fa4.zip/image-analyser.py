import json
import os
import logging
import boto3
import requests


def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message, response_card):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ElicitSlot',
            'intentName': intent_name,
            'slots': slots,
            'slotToElicit': slot_to_elicit,
            'message': message,
            'responseCard': response_card
        }
    }


def close(session_attributes, fulfillment_state, message):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message
        }
    }

    return response


def build_validation_result(is_valid, violated_slot, message_content):
    return {
        'isValid': is_valid,
        'violatedSlot': violated_slot,
        'message': {'contentType': 'PlainText', 'content': message_content}
    }

    
def validate_input_analyse_image(intent_name, slot_link):
    
    if slot_link is None:
        return build_validation_result(False,'Input_Type', "Please provide S3 link for image file. Max file size alllowed is 5 MB")

    return build_validation_result(True, None, None)
    
def analyse_image(intent_request):
    
    if 'Link' in intent_request['currentIntent']['slots']:
        file_link = intent_request['currentIntent']['slots']['Link']
    else:
        file_link = None
    
    resp = ""
    source = intent_request['invocationSource']
    output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    intent_name = intent_request['currentIntent']['name']

    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        slots = intent_request['currentIntent']['slots']
        validation_result = validate_input_analyse_image(intent_name, file_link)
            
        if not validation_result['isValid']:
            slots[validation_result['violatedSlot']] = None
            return elicit_slot(
                output_session_attributes,
                intent_request['currentIntent']['name'],
                slots,
                validation_result['violatedSlot'],
                validation_result['message'],
                None
                )
        
        return delegate(output_session_attributes, slots)
        
    file_info = bot-helper.get_bucket_and_key_from_uri(file_link)
    print(file_info)
    if 'extension' in file_info:
        if file_info['file_info'].lower() in ['jpeg', 'jpg', 'png']:
            output_content = 'file is supported
    return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': output_content
        }
    )
    
    
def get_text_from_image(bucket, object_key):
    s3 = boto3.client('s3')
    rekog_client = boto3.client('rekognition')
    response = s3.get_object(Bucket=bucket, Key=object_key)
    all_labels, all_texts, all_mod = list(),list(), list()
    msg = ""
    if response['ContentType'].split('/')[0] == 'image':
        response_labels = rekog_client.detect_labels(
            Image={'S3Object': {'Bucket': bucket,'Name': object_key}                    
            })

        response_text = rekog_client.detect_text(
            Image={'S3Object': {'Bucket': bucket,'Name': object_key}                    
            })

        for label in response_labels['Labels']:
            #all_labels.append( label['Name'] + "; Confidence = " + str(label['Confidence'])[:2] )
            all_labels.append(label['Name'])

        for txt in response_text['TextDetections']:
            # all_texts.append(txt['DetectedText'] + "; Confidence = " + str(label['Confidence'])[:2] )
            all_texts.append(txt['DetectedText'])

        image_type = str.lower(response['ContentType'].split('/')[1].strip())
        
        # only JPG ad PNG is supported by Detect Moderation
        if image_type in ['jpg', 'jpeg', 'png']:
            print('Getting Moderation Labels')
            for item in rekog_client.detect_moderation_labels(Image={'S3Object': {'Bucket': bucket,'Name': object_key}}, MinConfidence=50)['ModerationLabels']:
                all_mod.append(item['Name'] + "; Confidence = " + str(item['Confidence'])[:2] + "; ParentName = " + item['ParentName'])


        labels_string = ",".join(all_labels)
        text_string = ",".join(all_texts)
        
        msg = msg + "\nImage : {0} , Labels Count : {1} , Labels Detected : {2} ".format(object_key, len(all_labels),labels_string )
        msg = msg + "\nText Count: {0} , Text Detected : {1} ".format(len(all_texts), text_string)
        msg = msg + "\nModeration Label: {0}".format(",".join(all_mod))
        
    return msg