import json
import urllib.parse
import boto3
import os

def get_bucket_and_key_from_uri(file_uri):
    bucket = ''
    key = ''
    extension = ''
    temp = file_uri.replace('https://s3.amazonaws.com/', '')
    bucket = temp.split('/')[0]
    key = temp.replace(bucket + "/", '')
    extension = file_uri.split('.')[-1]
    return {'bucket':bucket, 'key': key , 'extension': extension]
    
    
    
def get_text_from_image(bucket, key):
    s3 = boto3.client('s3')
    rekog_client = boto3.client('rekognition')
    response = s3.get_object(Bucket=bucket, Key=object_key)
    if response['ContentType'].split('/')[0] == 'image':
        response_labels = rekog_client.detect_labels(
            Image={'S3Object': {'Bucket': bucket,'Name': object_key}                    
            })

        response_text = rekog_client.detect_text(
            Image={'S3Object': {'Bucket': bucket,'Name': object_key}                    
            })

        for label in response_labels['Labels']:
            all_labels.append("Name= " + label['Name'] + "; Confidence= " + str(label['Confidence']) )

        for txt in response_text['TextDetections']:
            all_texts.append("Text= " + txt['DetectedText'] + "; Confidence= " + str(label['Confidence']) )

        image_type = str.lower(response['ContentType'].split('/')[1].strip())
        
        # only JPG ad PNG is supported by Detect Moderation
        if image_type in ['jpg', 'jpeg', 'png']:
            print('Getting Moderation Labels')
            for item in rekog_client.detect_moderation_labels(Image={'S3Object': {'Bucket': bucket,'Name': object_key}}, MinConfidence=30)['ModerationLabels']:
                all_mod.append("Label= " + item['Name'] + "; Confidence= " + str(item['Confidence']) + "; ParentName= " + item['ParentName'])


        labels_string = ",".join(all_labels)
        text_string = ",".join(all_texts)
        
        msg = msg + "\nImage : {0} , Labels Count : {1} , Labels Detected : {2} ".format(object_key, len(all_labels),labels_string )
        msg = msg + "\nText Count: {0} , Text Detected : {1} ".format(len(all_texts), text_string)
        msg = msg + "\nModeration Label: {0}".format(",".join(all_mod))