

import json
import os
import logging
import boto3
import requests

######## Convert SSML to Card text ############
from html.parser import HTMLParser
from six import PY2
try:
    from HTMLParser import HTMLParser
except ImportError:
    from html.parser import HTMLParser


class SSMLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.full_str_list = []
        if not PY2:
            self.strict = False
            self.convert_charrefs = True

    def handle_data(self, d):
        self.full_str_list.append(d)

    def get_data(self):
        return ''.join(self.full_str_list)


def convert_html_to_text(html_data):
    # convert ssml speech to text, by removing html tags
    s = SSMLStripper()
    s.feed(html_data)
    return s.get_data()
input = "https://s3.amazonaws.com/amazon-ai-contest/images/IoT.png"
#doc = convert_html_to_text(requests.get(input).text)
s3 = boto3.client('s3')
bucket ='amazon-ai-contest'
key =  'images/IoT.png'

rekog_client = boto3.client('rekognition')
response = s3.get_object(Bucket=bucket, Key=key)
response_text = rekog_client.detect_text(
            Image={'S3Object': {'Bucket': bucket,'Name': key}                    
            })
response_labels = rekog_client.detect_labels(
                    Image={'S3Object': {'Bucket': bucket,'Name': key}                    
                    })
i=1